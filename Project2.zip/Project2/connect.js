const express = require('express');
const oracledb = require('oracledb');
const app = express();
const port = 3000;

// OracleDB connection settings
const dbConfig = {
    user          : "Airport_Management",
    password      : "1234",  // contains the hr schema password
    connectString : "localhost:1522/orclpdb"
};

// Serve static files (HTML, CSS, etc.)
app.use(express.static('public'));

// Body parsing middleware
app.use(express.urlencoded({ extended: false }));

// Login route
app.post('/login', async (req, res) => {
    const { login_id, password } = req.body;

    console.log(result);
    try {
        const connection = await oracledb.getConnection(dbConfig);
        const result = await connection.execute(
            'SELECT COUNT(*) AS COUNT FROM PASSENGER p JOIN SIGN_IN s ON p.PASSENGER_ID = s.PASSENGER_ID WHERE s.LOGIN_ID = :login_id AND s.PASSWORD = :password',
            { login_id, password }
        );
        //console.log(result);
        

        if (result.rows[0].COUNT > 0) {
            console.log("working");
            res.redirect('/buy_ticket.html');
        } else {
            console.log("Not_ working");
            res.redirect('/index.html');
        }

        await connection.close();
    } catch (error) {
        console.error('Error:', error);
        res.redirect('/index.html'); // Redirect on error
    }
    
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
