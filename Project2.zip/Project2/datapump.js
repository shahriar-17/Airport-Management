const oracledb = require('oracledb');
const axios=require('axios');


async function run() {
    const connection = await oracledb.getConnection({
        user          : "Airport_Management",
        password      : "1234",  // contains the hr schema password
        connectString : "localhost:1522/orclpdb"
    });
    // const username='Shahriar';

    // const result = await connection.execute(`SELECT * FROM "AIRPORT_MANAGEMENT"."PASSENGER" where "FIRST_NAME"='${username}'`);
    // console.log("Result is:", result.rows);

    // await connection.close();   // Always close connections

    const response= await axios.get('https://randomuser.me/api/?results=5');
    
    for(const person of response.data.results){
        const p_id=person.location.street.number;
        const fname=person.name.first;
        const lname=person.name.last;
        const email=person.email;
        const age=person.dob.age;
        const Login_id=person.location.postcode;
        const address=person.location.city;
        await connection.execute(
            `INSERT INTO "AIRPORT_MANAGEMENT"."PASSENGER" VALUES('${p_id}','${fname}','${lname}','${email}','${age}','${Login_id}','${address}')`
        );
    }

    await connection.commit();
}



run();